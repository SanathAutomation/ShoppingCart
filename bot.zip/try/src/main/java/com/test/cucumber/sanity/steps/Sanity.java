package com.test.cucumber.sanity.steps;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.Color;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.jayway.jsonpath.JsonPath;
import com.test.utils.BrowserEventManager;
import com.test.utils.ReuseableSpecifications;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.serenitybdd.rest.SerenityRest;
import org.openqa.selenium.support.ui.Select;

public class Sanity {
	public static String welcome = "//small[contains(text(),\"Welcome to Pizza Shoppe\")]";
	public static String getstarted = "//a[@class=\"get-started-link\"]";
	
	public static String firstname = "//input[@placeholder=\"Your first name\"]";
	public static String lastname = "//input[@placeholder=\"Your last name\"]";
	public static String email = "//input[@placeholder=\"Email\"]";
	public static String nextbutton = "//button[@type=\"submit\"]";
	public static String typemessage = "//*[@id=\"queryTextbox\"]";
	public static String sendbutton = "//*[@data-ele-name=\"send\"]";
	public static String vegpizza = "//*[@title=\"veg\"]";
	public static String cheese = "//*[@value=\"cheese_id\"]";
	public static String submit = "//*[@aria-label=\"Submit\"]";
	public static String thickitem = "(//*[@title=\"Thick Crust\"])[1]";
	public static String smallpizza = "//*[@title=\"Small\"]";
	public static String confirmYes = "//*[@title=\"Yes\"]";
	public static String thumbsup = "//*[@class=\"thumbs-up\"]";
	public static String selectFeedback = "//*[@placeholder=\"Select\"]";
	public static String submitfeedback = "(//*[@aria-label=\"Submit\"])[2]";
	
	
	
	//*[@placeholder="Select"]
	
	
	

			//h2//following-sibling::p
			//button OK
	ChromeDriver driver;
	Response response;
	/*
	 * @Before("Setup") public void SetupBrowser(){
	 * 
	 * 
	 * }
	 */
	
	@When("^User hits end point$")
	public void user_hits_end_point() throws Throwable {
	   RestAssured.baseURI="http://universities.hipolabs.com";
	   response=SerenityRest.rest().spec(ReuseableSpecifications.GenericRequestSpec()).given().get("/search?country=South+Africa");   
	   response.then().assertThat().statusCode(200).log();
	}

	@Then("^User should be able to see the province list$")
	public void user_should_be_able_to_see_the_province_list() throws Throwable {
	 // System.out.print(response.asString());
	  List <String> JsonString=JsonPath.parse(response.asString()).read("$..name");
	  for(int i=0;i<JsonString.size();i++) {
		  
		  if(JsonString.get(i).trim().contains("University of Witwatersrand")) {
			  System.out.println(JsonString.get(i));
		  }else {
			//  System.out.println(JsonString.get(i)); 
		  }
	  }
	   
	}
	
	
	@When("^I logged in to website$")
	public void i_logged_in_to_website_with_username_and_password(String arg1, String arg2) throws Throwable {
		ChromeOptions options = new ChromeOptions();
	    System.setProperty("webdriver.chrome.driver", "C:\\Users\\SChakrabor\\Softwares\\chromedriver_win32\\chromedriver.exe");
	     driver =new ChromeDriver(options);
	     driver.manage().window().maximize();
	     driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	     driver.get("https://c0.avaamo.com/web_channels/d0880907-3408-4c8d-9226-7648880a94fa/demo.html?banner=true&demo=true&banner_text=%20&banner_title=This%20is%20how%20the%20chat%20agent%20shows%20up");
	   driver.findElement(By.xpath(welcome)).click();
	   driver.findElement(By.xpath(getstarted)).click();
	   System.out.println("Provide details");
	   Thread.sleep(2);
	   driver.switchTo().frame("avaamoIframe");
	   System.out.println("moved to iframe");
	   driver.findElement(By.xpath(firstname)).sendKeys("sana");
	   driver.findElement(By.xpath(lastname)).sendKeys("chak");
	   driver.findElement(By.xpath(email)).sendKeys("abc123@gmail.com");
	   driver.findElement(By.xpath(nextbutton)).click();
	   System.out.println("Clicked Next button");
	   Thread.sleep(2);
	   
	   
	   
	   
	   
	   
	 
	   
	   
	   
	
	   
	}

	@When("^I added item to the shopping cart$")
	public void i_added_item_to_the_shopping_cart() throws Throwable {	
		   Thread.sleep(10);
		   driver.findElement(By.xpath(typemessage)).sendKeys("I want to order a pizza");
		   driver.findElement(By.xpath(sendbutton)).click();
		   Thread.sleep(2);
		   driver.findElement(By.xpath(vegpizza)).click();
		   driver.findElement(By.xpath(cheese)).click();
		   driver.findElement(By.xpath(submit)).click();
		   System.out.println("Clicked on submit");
		   driver.findElement(By.xpath(thickitem)).click();
		   driver.findElement(By.xpath(smallpizza)).click();
		   System.out.println("Small pizza selected");
		   
		   

	}

	@Then("^I validate that able to place an order$")
	public void i_validate_that_able_to_place_an_order() throws Throwable {
		   driver.findElement(By.xpath(confirmYes)).click();
		   driver.findElement(By.xpath(thumbsup)).click();
		   System.out.println("Liked the product");
		   //driver.findElement(By.xpath(selectFeedback)).click();
		   System.out.println("Feedback needs to be selected");
		   //driver.switchTo().frame("avaamoIframe");
		   Select feedback = new Select(driver.findElement(By.xpath(selectFeedback)));
		   feedback.selectByVisibleText("Average");
		   
		   driver.findElement(By.xpath(submitfeedback)).click();
	}
	
	@After("@CloseBrowser")
    public void closeBrowser(){
		driver.close();
		/*
		 * try { if (browser != null) { browser.closeBrowser(); } } catch (Exception e)
		 * { e.printStackTrace(); }
		 */
	}
}
