This framework is based on BDD with Cucumber approach 

Behavior Driven Development (BDD) is a software development approach that emphasizes collaboration and communication among developers, business analysts, and other stakeholders. BDD is typically used to build software applications that meet specific business requirements or user needs. Cucumber is a popular BDD testing framework that allows you to write executable specifications in a natural language format.

So we are having a .feature file (test.feature) written with the help of Gherkin language.
We have step defination file called as Sanity.java where all the code implementation is there.
We also have Runner file called as SanityRunner.java.

To execute the test cases we need to run the test either with mvn test from CLI or we can use run as --> Junit test in Runner class. 
This runner class basically has RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = { "src/test/resources/Sanity/test.feature" } , tags = {
"@tag1" })
public class SanityRunner  { }

If we want to execute web UI Automation , we can use tag as @tag1 in Runner class, whereas if we want to run the API call we can use tag as @api in Runner class.
